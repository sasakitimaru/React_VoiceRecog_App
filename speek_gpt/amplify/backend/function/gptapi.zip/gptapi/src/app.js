/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/


/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	YOUR_API_KEY
Amplify Params - DO NOT EDIT */

const express = require('express')
const bodyParser = require('body-parser')
const axios = require('axios');
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')

// declare a new express app
const app = express()
app.use(bodyParser.json())
app.use(awsServerlessExpressMiddleware.eventContext())

// Enable CORS for all methods
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Headers", "*")
  next()
});

app.post('/gptapi', async function(req, res) {
  const apiKey = YOUR_API_KEY;
  const messageForAI = req.body.messageForAI;

  const data = {
    model: 'gpt-3.5-turbo',
    messages: messageForAI,
  }
  console.log('test')

  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${apiKey}`,
  };
  try {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', data, { headers });
    console.log('response', response.data.choices[0].message.content);
    res.json(response.data.choices[0].message.content);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred while fetching data from OpenAI API' });
  }
});


module.exports = app
